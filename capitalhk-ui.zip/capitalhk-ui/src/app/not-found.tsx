import NotFoundComponent from "@/components/common/molecule/not-found/NotFoundComponent"

async function NotFound() {
  return <NotFoundComponent />
}

export default NotFound
