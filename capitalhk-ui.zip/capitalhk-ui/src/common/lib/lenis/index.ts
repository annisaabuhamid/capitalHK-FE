"use client"

export * from "lenis/react"
