declare module "react-scroll-percentage"
