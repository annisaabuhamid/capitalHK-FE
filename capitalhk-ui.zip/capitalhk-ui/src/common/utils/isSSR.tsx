export const isSSR = typeof window === "undefined"
