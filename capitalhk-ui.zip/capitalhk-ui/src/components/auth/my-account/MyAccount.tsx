import MyAccountForm from "@/components/auth/my-account/MyAccountForm"

type Props = {}

function MyAccount({}: Props) {
  return (
    <div>
      <MyAccountForm />
    </div>
  )
}

export default MyAccount
