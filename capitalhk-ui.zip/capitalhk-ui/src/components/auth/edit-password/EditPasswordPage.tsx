import React from "react"
import EditPasswordForm from "@/components/auth/edit-password/EditPasswordForm"

function EditPasswordPage() {
  return <EditPasswordForm />
}

export default EditPasswordPage
