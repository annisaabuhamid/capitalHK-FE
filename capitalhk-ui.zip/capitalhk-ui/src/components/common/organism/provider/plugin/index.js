/* eslint-disable import/extensions */
//  Gsap Plugin import here

export { default as Gsap } from "../../../../../../public/plugins/gsap.js"
export { default as ScrollSmoother } from "../../../../../../public/plugins/gsap-scroll-smoother.js"
export { default as ScrollToPlugin } from "../../../../../../public/plugins/gsap-scroll-to-plugin.js"
export { default as ScrollTrigger } from "../../../../../../public/plugins/gsap-scroll-trigger.js"
